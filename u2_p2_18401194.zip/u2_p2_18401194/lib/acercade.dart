import 'package:flutter/material.dart';

class Acercade extends StatefulWidget{
  const Acercade({Key? key}): super(key: key);
  @override

  State<Acercade> createState()=>_Acercade();
}

class _Acercade extends State<Acercade>{

  @override
  Widget build(BuildContext context) {
    return Column(

      children: [

        Padding(padding: EdgeInsets.all(30)),
        const Text("Presentación",
        style: TextStyle(fontSize: 30,color: Colors.green, fontWeight: FontWeight.bold),textAlign: TextAlign.center),

        SizedBox(
          height: 60.0,

          child: Image.asset('assets/yop.jpg'),
        ),
        SizedBox(width: 150,
          child:Text("Daniel Rojas Ramírez Estudiante de la carrera de ingenieria en sistemas computacionales",
              style: TextStyle(fontSize: 15,color: Colors.black26, fontWeight: FontWeight.normal),textAlign: TextAlign.center),
        )


      ],
    );
  }

}
import 'package:flutter/material.dart';
List comida =["TACOS","ENCHILADAs","POZOLEs","SOPES"];
class Relleno extends StatefulWidget{
  const Relleno({Key? key}): super(key: key);
  @override

  State<Relleno> createState()=>_Relleno();
}

class _Relleno extends State<Relleno>{
  String elegido="TACOS";
  String _elegidoComida =comida.first;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(height: 30,),
          Text("Comida Favorita"),
          SizedBox(height: 30,),
          Row(mainAxisAlignment: MainAxisAlignment.center,children: [
            DropdownButton(
                value: _elegidoComida,
                items: comida.map((valor){
                  return DropdownMenuItem(child: Text(valor),value: valor,);
                }).toList(),
                onChanged: (valor){
                  setState(() {
                    _elegidoComida=valor.toString();
                    elegido=valor.toString();
                  });
                }

            ),
            OutlinedButton(onPressed: (){
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text("Qué buen gusto las ${elegido} tambien son mis favoritos"),));
            }, child: Text("RESOLVER"))
          ],)
        ],
      ),
    );
  }


}
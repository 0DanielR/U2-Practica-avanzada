// TODO Implement this library.
import 'package:flutter/material.dart';
enum EstadoCivil {casado, soltero}
List estado =["Estudiante","Nini","Trabajador"];
class Registro extends StatefulWidget{
  const Registro({Key? key}): super(key: key);
  @override

    State<Registro> createState()=>_RegistroState();
}

class _RegistroState extends State<Registro>{
  EstadoCivil _status =EstadoCivil.soltero;

  final texto1=TextEditingController();
  String elegido="Estudiante";
  String _estadoElegido=estado.first;
  @override

  Widget build(BuildContext context) {
    return

       ListView(
        padding: EdgeInsets.all(30),
        children: [
          SizedBox(height: 30,),
          Padding(padding: EdgeInsets.all(20),
          child: TextField(controller: texto1,
            decoration: InputDecoration(labelText: "Nombre Completo",border: UnderlineInputBorder()),
          ),
          ),
          SizedBox(height: 30,),
          Row(mainAxisAlignment: MainAxisAlignment.center,children: [
            DropdownButton(
                value: _estadoElegido,
                items: estado.map((valor){
                  return DropdownMenuItem(child: Text(valor),value: valor,);
                }).toList(),
                onChanged: (valor){
                  setState(() {
                    _estadoElegido=valor.toString();
                    elegido=valor.toString();
                  });
                }

            ),
          ],),
          RadioListTile(
              title: Text("SOLTERO"),
              value: EstadoCivil.soltero,
              groupValue: _status,
              onChanged: (EstadoCivil? valor){
                setState(() {
                  _status=valor!;
                });
              }),
          RadioListTile(
              title: Text("CASADO"),
              value: EstadoCivil.casado,
              groupValue: _status,
              onChanged: (EstadoCivil? valor){
                setState(() {
                  _status=valor!;
                });
              }
              ),
         OutlinedButton(onPressed: (){
           ver(texto1.text,_status.toString(),elegido);
         }, child: Text("Ver"))
        ],
      );
  }
  void ver(String text, String text2,String text3){
    showDialog(context: context, builder: (BuildContext context){
      return AlertDialog(
        title: Text("Datos personales"),
        content: Text("Bienvenido ${text3}, ${text} con situación ${text2}"),
        actions: [TextButton(onPressed: (){
          Navigator.of(context).pop();
        }, child: Text("ok"))],
      );
    });
  }
  
}
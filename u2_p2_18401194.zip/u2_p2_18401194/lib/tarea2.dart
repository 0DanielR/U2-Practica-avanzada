import 'package:flutter/material.dart';
import 'package:u2_p2_18401194/registro.dart';
import 'package:u2_p2_18401194/acercade.dart';
import 'package:u2_p2_18401194/relleno.dart';

class Tarea2 extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _Tarea2();
  }
}

class _Tarea2 extends State<Tarea2>{
  int _indice=0;
  final texto1 =TextEditingController();

  void _cambiarIndice(int indice){
    setState(() {
      _indice=indice;
    });
  }

  final List<Widget> _paginas=[

    Registro(),
    Acercade(),
    Relleno()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Practica 2"),actions: [
        IconButton(onPressed: (){
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Este programa esta realizado por Daniel Rojas Ramírez")));
        }, icon: Icon(Icons.info))
      ],),
      body: _paginas[_indice],
      bottomNavigationBar: BottomNavigationBar(
        items: [

          BottomNavigationBarItem(icon: Icon(Icons.app_registration),label: "Registro"),
          BottomNavigationBarItem(icon: Icon(Icons.account_circle),label: "Acerca de"),
          BottomNavigationBarItem(icon: Icon(Icons.accessible_sharp),label: "Ya no se que poner"),
        ],
        currentIndex: _indice,
        showUnselectedLabels: false,
        iconSize: 30,
        backgroundColor: Colors.green,
        selectedItemColor: Colors.deepPurpleAccent,
        onTap: _cambiarIndice,
      ),
    );
  }


}